import { VercelRequest, VercelResponse } from '@vercel/node';
import connectToDatabase from './lib/mongodb';
import Product from './models/Product';

export default async function handler(req: VercelRequest, res: VercelResponse) {
  await connectToDatabase();

  const { method } = req;

  switch (method) {
    case 'GET':
      try {
        const products = await Product.find({});
        res.status(200).json(products);
      } catch (error) {
        res.status(400).json({ success: false });
      }
      break;
    case 'POST':
      try {
        const product = await Product.create(req.body);
        res.status(201).json(product);
      } catch (error) {
        res.status(400).json({ success: false });
      }
      break;
    case 'PUT':
        try {
            const { id, ...updates } = req.body;
            const product = await Product.findByIdAndUpdate(id, updates, { new: true });
            res.status(200).json(product);
        } catch (error) {
            res.status(400).json({ success: false });
        }
        break;
    case 'DELETE':
        try {
            const { id } = req.query;
            await Product.findByIdAndDelete(id);
            res.status(200).json({ success: true });
        } catch (error) {
            res.status(400).json({ success: false });
        }
        break;
    default:
      res.setHeader('Allow', ['GET', 'POST', 'PUT', 'DELETE']);
      res.status(405).end(`Method ${method} Not Allowed`);
  }
}
