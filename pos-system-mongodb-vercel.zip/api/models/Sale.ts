import mongoose from 'mongoose';

const SaleSchema = new mongoose.Schema({
  items: [
    {
      id: String,
      name: String,
      price: Number,
      quantity: Number,
      category: String,
      image: String,
    },
  ],
  total: { type: Number, required: true },
  timestamp: { type: Number, required: true },
  date: { type: String, required: true },
  paymentMethod: { type: String, enum: ['cash', 'card', 'transfer'], required: true },
});

export default mongoose.models.Sale || mongoose.model('Sale', SaleSchema);
