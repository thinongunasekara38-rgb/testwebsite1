import { VercelRequest, VercelResponse } from '@vercel/node';
import connectToDatabase from './lib/mongodb';
import Sale from './models/Sale';
import Product from './models/Product';

export default async function handler(req: VercelRequest, res: VercelResponse) {
  await connectToDatabase();

  const { method } = req;

  switch (method) {
    case 'GET':
      try {
        const sales = await Sale.find({}).sort({ timestamp: -1 });
        res.status(200).json(sales);
      } catch (error) {
        res.status(400).json({ success: false });
      }
      break;
    case 'POST':
      try {
        const { items, total, timestamp, date, paymentMethod } = req.body;
        const sale = await Sale.create({ items, total, timestamp, date, paymentMethod });
        
        // Update stock
        for (const item of items) {
          await Product.findByIdAndUpdate(item.id, { $inc: { stock: -item.quantity } });
        }
        
        res.status(201).json(sale);
      } catch (error) {
        res.status(400).json({ success: false });
      }
      break;
    default:
      res.setHeader('Allow', ['GET', 'POST']);
      res.status(405).end(`Method ${method} Not Allowed`);
  }
}
