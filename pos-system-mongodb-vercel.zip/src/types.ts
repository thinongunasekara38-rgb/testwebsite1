export interface Product {
  id: string;
  name: string;
  price: number;
  category: string;
  stock: number;
  image: string;
}

export interface Sale {
  id: string;
  items: CartItem[];
  total: number;
  timestamp: number;
  date: string;
  paymentMethod: 'cash' | 'card' | 'transfer';
}

export interface CartItem extends Product {
  quantity: number;
}

export type View = 'dashboard' | 'pos' | 'inventory' | 'sales-history';
