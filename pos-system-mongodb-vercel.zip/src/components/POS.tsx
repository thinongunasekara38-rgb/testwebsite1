import { useState, useMemo } from 'react';
import { Search, Plus, Minus, Trash2, CreditCard, Banknote, Smartphone, CheckCircle2, ShoppingCart } from 'lucide-react';
import { Product, CartItem, Sale } from '../types';
import { cn } from '../utils/cn';
import { motion, AnimatePresence } from 'framer-motion';

interface POSProps {
  products: Product[];
  onSale: (items: CartItem[], total: number, method: Sale['paymentMethod']) => void;
}

const POS = ({ products, onSale }: POSProps) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const categories = useMemo(() => ['All', ...new Set(products.map(p => p.category))], [products]);

  const filteredProducts = products.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || p.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === id) {
        const newQty = Math.max(0, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    }).filter(item => item.quantity > 0));
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(item => item.id !== id));
  };

  const subtotal = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);
  const tax = subtotal * 0.08;
  const total = subtotal + tax;

  const handleCheckout = (method: Sale['paymentMethod']) => {
    setIsCheckingOut(true);
    // Simulate process
    setTimeout(() => {
      onSale(cart, total, method);
      setCart([]);
      setIsCheckingOut(false);
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 2000);
    }, 800);
  };

  return (
    <div className="flex h-full animate-in fade-in duration-500 overflow-hidden">
      <div className="flex-1 flex flex-col p-8 overflow-hidden">
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="relative flex-1 group">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-600 transition-colors" size={20} />
            <input 
              type="text"
              placeholder="Search products..."
              className="w-full pl-11 pr-4 py-3 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all shadow-sm"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            {categories.map(category => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={cn(
                  "px-6 py-3 rounded-xl whitespace-nowrap font-medium transition-all shadow-sm",
                  selectedCategory === category 
                    ? "bg-indigo-600 text-white shadow-indigo-200" 
                    : "bg-white text-slate-600 border border-slate-200 hover:border-indigo-500 hover:text-indigo-600"
                )}
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        <div className="flex-1 overflow-y-auto pr-2 scrollbar-thin">
          <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-6">
            <AnimatePresence mode="popLayout">
              {filteredProducts.map(product => (
                <motion.div
                  layout
                  key={product.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  whileHover={{ y: -4 }}
                  onClick={() => addToCart(product)}
                  className="bg-white rounded-2xl border border-slate-100 p-4 shadow-sm hover:shadow-md transition-all cursor-pointer group flex flex-col h-full"
                >
                  <div className="relative aspect-video rounded-xl overflow-hidden mb-4">
                    <img src={product.image} alt={product.name} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
                    <div className="absolute top-2 right-2 bg-indigo-600 text-white text-xs font-bold px-2 py-1 rounded-lg">
                      ${product.price.toFixed(2)}
                    </div>
                  </div>
                  <div className="flex-1">
                    <h4 className="font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">{product.name}</h4>
                    <p className="text-xs text-slate-500 mt-1">{product.category}</p>
                  </div>
                  <div className="flex justify-between items-center mt-4">
                    <span className={cn("text-[10px] font-bold px-2 py-0.5 rounded-full uppercase", 
                      product.stock > 10 ? "bg-emerald-50 text-emerald-600" : "bg-rose-50 text-rose-600"
                    )}>
                      {product.stock} in stock
                    </span>
                    <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <Plus size={18} />
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      </div>

      <div className="w-[450px] bg-white border-l border-slate-200 flex flex-col shadow-2xl relative">
        <div className="p-6 border-b border-slate-100">
          <h3 className="text-xl font-bold text-slate-900">Current Order</h3>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-4 scrollbar-thin">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-slate-400 opacity-50 space-y-4">
              <ShoppingCart size={64} />
              <p className="font-medium">No items in cart</p>
            </div>
          ) : (
            cart.map(item => (
              <motion.div 
                layout
                initial={{ x: 20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                key={item.id} 
                className="flex items-center gap-4 bg-slate-50 p-4 rounded-2xl group border border-transparent hover:border-indigo-100 transition-all"
              >
                <div className="w-16 h-16 rounded-xl overflow-hidden shadow-sm">
                  <img src={item.image} className="w-full h-full object-cover" />
                </div>
                <div className="flex-1">
                  <h4 className="font-bold text-sm text-slate-900 truncate w-32">{item.name}</h4>
                  <div className="text-indigo-600 font-bold text-sm">${(item.price * item.quantity).toFixed(2)}</div>
                </div>
                <div className="flex items-center gap-3 bg-white px-3 py-1.5 rounded-xl border border-slate-200 shadow-sm">
                  <button onClick={() => updateQuantity(item.id, -1)} className="text-slate-400 hover:text-indigo-600 transition-colors"><Minus size={14} /></button>
                  <span className="font-bold text-sm w-4 text-center">{item.quantity}</span>
                  <button onClick={() => updateQuantity(item.id, 1)} className="text-slate-400 hover:text-indigo-600 transition-colors"><Plus size={14} /></button>
                </div>
                <button onClick={() => removeFromCart(item.id)} className="text-slate-300 hover:text-rose-600 transition-colors opacity-0 group-hover:opacity-100"><Trash2 size={18} /></button>
              </motion.div>
            ))
          )}
        </div>

        <div className="p-8 border-t border-slate-100 space-y-6 bg-slate-50/50">
          <div className="space-y-2">
            <div className="flex justify-between text-slate-500 font-medium">
              <span>Subtotal</span>
              <span>${subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-slate-500 font-medium">
              <span>Tax (8%)</span>
              <span>${tax.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-2xl font-black text-slate-900 pt-2 border-t border-slate-200">
              <span>Total</span>
              <span className="text-indigo-600">${total.toFixed(2)}</span>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <button 
              disabled={cart.length === 0 || isCheckingOut}
              onClick={() => handleCheckout('cash')}
              className="flex flex-col items-center gap-2 p-3 bg-white border border-slate-200 rounded-2xl hover:border-indigo-500 hover:bg-indigo-50 hover:text-indigo-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed group shadow-sm"
            >
              <Banknote size={24} className="text-slate-400 group-hover:text-indigo-600" />
              <span className="text-xs font-bold">Cash</span>
            </button>
            <button 
              disabled={cart.length === 0 || isCheckingOut}
              onClick={() => handleCheckout('card')}
              className="flex flex-col items-center gap-2 p-3 bg-white border border-slate-200 rounded-2xl hover:border-indigo-500 hover:bg-indigo-50 hover:text-indigo-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed group shadow-sm"
            >
              <CreditCard size={24} className="text-slate-400 group-hover:text-indigo-600" />
              <span className="text-xs font-bold">Card</span>
            </button>
            <button 
              disabled={cart.length === 0 || isCheckingOut}
              onClick={() => handleCheckout('transfer')}
              className="flex flex-col items-center gap-2 p-3 bg-white border border-slate-200 rounded-2xl hover:border-indigo-500 hover:bg-indigo-50 hover:text-indigo-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed group shadow-sm"
            >
              <Smartphone size={24} className="text-slate-400 group-hover:text-indigo-600" />
              <span className="text-xs font-bold">Transfer</span>
            </button>
          </div>
        </div>

        <AnimatePresence>
          {showSuccess && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="absolute inset-0 bg-white/95 flex flex-col items-center justify-center p-8 z-50 text-center"
            >
              <div className="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mb-4">
                <CheckCircle2 size={48} />
              </div>
              <h3 className="text-2xl font-black text-slate-900 mb-2">Order Completed!</h3>
              <p className="text-slate-500">Transaction was processed successfully.</p>
              <div className="mt-8 text-4xl font-black text-emerald-600">${total.toFixed(2)}</div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default POS;
