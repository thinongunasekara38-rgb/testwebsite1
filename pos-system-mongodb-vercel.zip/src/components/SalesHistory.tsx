import { useState } from 'react';
import { Search, Filter, CreditCard, Banknote, Smartphone, ChevronRight, History } from 'lucide-react';
import { Sale } from '../types';
import { cn } from '../utils/cn';

interface SalesHistoryProps {
  sales: Sale[];
}

const MethodBadge = ({ method }: { method: Sale['paymentMethod'] }) => {
  const config = {
    cash: { icon: Banknote, color: 'text-emerald-600 bg-emerald-50' },
    card: { icon: CreditCard, color: 'text-blue-600 bg-blue-50' },
    transfer: { icon: Smartphone, color: 'text-indigo-600 bg-indigo-50' },
  };
  const { icon: Icon, color } = config[method];
  return (
    <div className={cn("flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold capitalize shadow-sm", color)}>
      <Icon size={14} />
      {method}
    </div>
  );
};

export const SalesHistory = ({ sales }: SalesHistoryProps) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredSales = sales.filter(sale => 
    sale.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
    sale.paymentMethod.toLowerCase().includes(searchTerm.toLowerCase()) ||
    sale.items.some(item => item.name.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="p-8 space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Sales History</h1>
          <p className="text-slate-500">Detailed record of all transactions and business activities.</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="bg-white px-6 py-3 rounded-xl border border-slate-200 shadow-sm flex items-center gap-3">
            <span className="text-slate-400 text-sm font-medium">Total Volume:</span>
            <span className="text-indigo-600 font-bold text-lg">${sales.reduce((acc, s) => acc + s.total, 0).toFixed(2)}</span>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex flex-col md:flex-row gap-4 justify-between items-center bg-slate-50/50">
          <div className="relative w-full md:w-96 group">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-600 transition-colors" size={20} />
            <input 
              type="text"
              placeholder="Search by Order ID, payment method or item..."
              className="w-full pl-11 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all shadow-sm"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-2">
            <button className="flex items-center gap-2 px-4 py-2.5 text-slate-600 bg-white rounded-xl border border-slate-200 hover:border-indigo-500 hover:text-indigo-600 transition-all shadow-sm">
              <Filter size={18} />
              <span className="text-sm font-bold">Filter Range</span>
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 text-slate-500 text-sm font-semibold uppercase tracking-wider">
                <th className="px-6 py-4">Transaction Details</th>
                <th className="px-6 py-4">Payment Method</th>
                <th className="px-6 py-4">Items</th>
                <th className="px-6 py-4">Amount</th>
                <th className="px-6 py-4 text-right">Receipt</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredSales.map(sale => (
                <tr key={sale.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-6 py-4">
                    <div className="space-y-1">
                      <div className="font-bold text-slate-900">Order #{sale.id.toUpperCase()}</div>
                      <div className="text-xs text-slate-400 flex items-center gap-1 font-medium">
                        <History size={12} />
                        {sale.date}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <MethodBadge method={sale.paymentMethod} />
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex -space-x-2">
                      {sale.items.slice(0, 3).map((item, idx) => (
                        <div key={idx} className="w-8 h-8 rounded-full border-2 border-white overflow-hidden shadow-sm" title={item.name}>
                          <img src={item.image} className="w-full h-full object-cover" />
                        </div>
                      ))}
                      {sale.items.length > 3 && (
                        <div className="w-8 h-8 rounded-full border-2 border-white bg-slate-100 text-[10px] font-bold text-slate-600 flex items-center justify-center shadow-sm">
                          +{sale.items.length - 3}
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="font-bold text-indigo-600 text-lg">${sale.total.toFixed(2)}</div>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all">
                      <ChevronRight size={20} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filteredSales.length === 0 && (
            <div className="py-20 text-center text-slate-400 flex flex-col items-center justify-center gap-4">
              <History size={48} className="opacity-20" />
              <p className="font-medium text-lg">No transactions found</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SalesHistory;
