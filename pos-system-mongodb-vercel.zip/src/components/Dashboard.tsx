import { 
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  AreaChart, Area 
} from 'recharts';
import { TrendingUp, DollarSign, Package, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { Product, Sale } from '../types';
import { cn } from '../utils/cn';

interface DashboardProps {
  products: Product[];
  sales: Sale[];
}

const StatCard = ({ title, value, icon: Icon, trend, trendValue, color }: any) => (
  <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
    <div className="flex justify-between items-start mb-4">
      <div className={cn("p-3 rounded-xl", color)}>
        <Icon size={24} className="text-white" />
      </div>
      <div className={cn(
        "flex items-center gap-1 text-sm font-medium",
        trend === 'up' ? "text-emerald-600" : "text-rose-600"
      )}>
        {trend === 'up' ? <ArrowUpRight size={16} /> : <ArrowDownRight size={16} />}
        {trendValue}%
      </div>
    </div>
    <div className="text-slate-500 text-sm font-medium mb-1">{title}</div>
    <div className="text-2xl font-bold text-slate-900">{value}</div>
  </div>
);

export const Dashboard = ({ products, sales }: DashboardProps) => {
  const totalRevenue = sales.reduce((acc, sale) => acc + sale.total, 0);
  const totalOrders = sales.length;
  const lowStockProducts = products.filter(p => p.stock < 15).length;
  const averageTicket = totalOrders > 0 ? totalRevenue / totalOrders : 0;

  // Mock data for chart - in real app, group sales by day
  const chartData = [
    { name: 'Mon', revenue: 450, orders: 12 },
    { name: 'Tue', revenue: 620, orders: 18 },
    { name: 'Wed', revenue: 580, orders: 15 },
    { name: 'Thu', revenue: 840, orders: 24 },
    { name: 'Fri', revenue: 790, orders: 20 },
    { name: 'Sat', revenue: 1100, orders: 32 },
    { name: 'Sun', revenue: 950, orders: 28 },
  ];

  return (
    <div className="p-8 space-y-8 animate-in fade-in duration-500">
      <div>
        <h1 className="text-3xl font-bold text-slate-900 mb-2">Business Overview</h1>
        <p className="text-slate-500">Welcome back! Here's what's happening today.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="Total Revenue" 
          value={`$${totalRevenue.toFixed(2)}`} 
          icon={DollarSign} 
          trend="up" 
          trendValue="12.5" 
          color="bg-indigo-600"
        />
        <StatCard 
          title="Total Orders" 
          value={totalOrders} 
          icon={ShoppingCart} 
          trend="up" 
          trendValue="8.2" 
          color="bg-violet-600"
        />
        <StatCard 
          title="Avg. Ticket" 
          value={`$${averageTicket.toFixed(2)}`} 
          icon={TrendingUp} 
          trend="down" 
          trendValue="2.4" 
          color="bg-blue-600"
        />
        <StatCard 
          title="Low Stock Items" 
          value={lowStockProducts} 
          icon={Package} 
          trend="up" 
          trendValue="4.1" 
          color="bg-amber-600"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-lg font-bold text-slate-900">Revenue Analysis</h3>
            <select className="bg-slate-50 border-none text-sm font-medium rounded-lg focus:ring-indigo-500">
              <option>Last 7 Days</option>
              <option>Last 30 Days</option>
            </select>
          </div>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#4f46e5" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                <Tooltip 
                  contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}}
                />
                <Area type="monotone" dataKey="revenue" stroke="#4f46e5" strokeWidth={3} fillOpacity={1} fill="url(#colorRevenue)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-lg font-bold text-slate-900">Recent Transactions</h3>
            <button className="text-indigo-600 text-sm font-semibold hover:underline">View All</button>
          </div>
          <div className="space-y-4">
            {sales.length === 0 ? (
              <div className="text-center py-12 text-slate-400">
                <p>No transactions found</p>
              </div>
            ) : (
              sales.slice(0, 5).map((sale) => (
                <div key={sale.id} className="flex items-center justify-between p-4 rounded-xl hover:bg-slate-50 transition-colors">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 font-bold">
                      {sale.items[0]?.name[0]}
                    </div>
                    <div>
                      <div className="font-semibold text-slate-900">{sale.items[0]?.name} {sale.items.length > 1 && `+ ${sale.items.length - 1} more`}</div>
                      <div className="text-xs text-slate-500">{sale.date} • {sale.paymentMethod}</div>
                    </div>
                  </div>
                  <div className="font-bold text-indigo-600">+${sale.total.toFixed(2)}</div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

import { ShoppingCart as ShoppingCartIcon } from 'lucide-react';
const ShoppingCart = ShoppingCartIcon;

export default Dashboard;
