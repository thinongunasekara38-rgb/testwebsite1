import { useState } from 'react';
import { useStore } from './store';
import { View } from './types';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import POS from './components/POS';
import Inventory from './components/Inventory';
import SalesHistory from './components/SalesHistory';
import { Toaster, toast } from 'react-hot-toast';

function App() {
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const store = useStore();

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard products={store.products} sales={store.sales} />;
      case 'pos':
        return <POS products={store.products} onSale={(items: any, total: number, method: any) => {
          store.recordSale(items, total, method);
          toast.success('Sale completed successfully!');
        }} />;
      case 'inventory':
        return (
          <Inventory 
            products={store.products} 
            onAdd={store.addProduct} 
            onUpdate={store.updateProduct} 
            onDelete={store.deleteProduct} 
          />
        );
      case 'sales-history':
        return <SalesHistory sales={store.sales} />;
      default:
        return <Dashboard products={store.products} sales={store.sales} />;
    }
  };

  return (
    <div className="flex h-screen bg-slate-50 text-slate-900 font-sans overflow-hidden">
      <Toaster position="top-right" />
      <Sidebar currentView={currentView} setView={setCurrentView} />
      <main className="flex-1 overflow-y-auto">
        {renderView()}
      </main>
    </div>
  );
}

export default App;
