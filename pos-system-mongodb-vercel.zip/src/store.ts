import { useState, useEffect } from 'react';
import { Product, Sale, CartItem } from './types';

const INITIAL_PRODUCTS: Product[] = [
  { id: '1', name: 'Premium Coffee Bean', price: 18.50, category: 'Beverage', stock: 45, image: 'https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=300&h=200&fit=crop' },
  { id: '2', name: 'Fresh Croissant', price: 4.25, category: 'Bakery', stock: 24, image: 'https://images.unsplash.com/photo-1555507036-ab1f4038808a?w=300&h=200&fit=crop' },
  { id: '3', name: 'Artisan Sourdough', price: 8.00, category: 'Bakery', stock: 12, image: 'https://images.unsplash.com/photo-1585478259715-876a6a81fc08?w=300&h=200&fit=crop' },
  { id: '4', name: 'Matcha Green Tea', price: 5.50, category: 'Beverage', stock: 30, image: 'https://images.unsplash.com/photo-1582793988951-9aed55099991?w=300&h=200&fit=crop' },
  { id: '5', name: 'Dark Chocolate', price: 3.50, category: 'Snacks', stock: 50, image: 'https://images.unsplash.com/photo-1511381939415-e44015466834?w=300&h=200&fit=crop' },
  { id: '6', name: 'Honey Lavender Latte', price: 6.25, category: 'Beverage', stock: 20, image: 'https://images.unsplash.com/photo-1572442388796-11668a67e53a?w=300&h=200&fit=crop' },
];

export const useStore = () => {
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('pos_products');
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  const [sales, setSales] = useState<Sale[]>(() => {
    const saved = localStorage.getItem('pos_sales');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('pos_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('pos_sales', JSON.stringify(sales));
  }, [sales]);

  const addProduct = (product: Omit<Product, 'id'>) => {
    setProducts([...products, { ...product, id: Math.random().toString(36).substr(2, 9) }]);
  };

  const updateProduct = (id: string, updates: Partial<Product>) => {
    setProducts(products.map(p => p.id === id ? { ...p, ...updates } : p));
  };

  const deleteProduct = (id: string) => {
    setProducts(products.filter(p => p.id !== id));
  };

  const recordSale = (items: CartItem[], total: number, paymentMethod: Sale['paymentMethod']) => {
    const newSale: Sale = {
      id: Math.random().toString(36).substr(2, 9),
      items,
      total,
      timestamp: Date.now(),
      date: new Date().toLocaleString(),
      paymentMethod,
    };

    setSales([newSale, ...sales]);

    // Update stock
    items.forEach(item => {
      const product = products.find(p => p.id === item.id);
      if (product) {
        updateProduct(item.id, { stock: product.stock - item.quantity });
      }
    });
  };

  return {
    products,
    sales,
    addProduct,
    updateProduct,
    deleteProduct,
    recordSale,
  };
};
